<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('login', function () {
    return view('login');
});

Route::get('admin', function () {
    return view('admin');
});

Route::get('signup', function () {
    return view('signup');
});
Route::get('publish', function () {
    return view('publish');
});

Route::get('blogs', function () {
    return view('blogs');
});
Route::POST('usersignup','UserController@signup');
Route::POST('userlogin','UserController@login');
route::get('userlogout','UserController@logout');


Route::POST('publish','PostController@store');


Route::GET('edit/{posts}/edit','PostController@edit');
Route::PUT('edit/{posts}','PostController@update');
Route::Delete('delete/{posts}','PostController@destroy');
